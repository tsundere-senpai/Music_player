# MusicPlayer (Skeleton)
This is a **source-only** Android Studio project skeleton for a music player with:
- Jetpack Compose (Material3 / Material You)
- ExoPlayer-based PlaybackService with crossfade pattern (two players)
- Room database skeleton
- SAF folder picker example

IMPORTANT: I cannot compile or produce an APK in this environment (no Android SDK / Build tools available here).  
You can open this project in Android Studio (Electric Eel or later recommended), let it download Gradle/SDK, then Build > Make Project to generate an APK.

Quick steps:
1. Open Android Studio -> File -> New -> Import Project -> select this folder.
2. Let Gradle sync. Install required SDK platforms if prompted (Android 33 recommended).
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Run on device or emulator.

If you want, I can also provide GitHub Actions CI YAML to auto-build an unsigned debug APK in the cloud.
