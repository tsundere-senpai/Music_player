rootProject.name = "MusicPlayer"
include(":app")
