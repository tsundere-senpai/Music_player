package com.example.musicplayer.playback

import android.net.Uri
import android.os.Bundle
import androidx.media.MediaBrowserServiceCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import kotlinx.coroutines.*

class PlaybackService : MediaBrowserServiceCompat() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var playerA: ExoPlayer? = null
    private var playerB: ExoPlayer? = null
    private var current: ExoPlayer? = null
    private var next: ExoPlayer? = null
    private var crossfadeMs = 3000L

    override fun onCreate() {
        super.onCreate()
        playerA = ExoPlayer.Builder(this).build()
        playerB = ExoPlayer.Builder(this).build()
        current = playerA
    }

    fun playTrack(uri: Uri) {
        current?.setMediaItem(MediaItem.fromUri(uri))
        current?.prepare()
        current?.playWhenReady = true
    }

    fun crossfadeTo(uri: Uri) {
        next = if (current === playerA) playerB else playerA
        next?.setMediaItem(MediaItem.fromUri(uri))
        next?.prepare()
        next?.volume = 0f
        next?.playWhenReady = true

        val steps = 30
        val delayPerStep = crossfadeMs / steps

        scope.launch {
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                current?.volume = 1 - t
                next?.volume = t
                delay(delayPerStep)
            }
            current?.stop()
            current = next
            next = null
        }
    }

    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?): BrowserRoot? {
        return BrowserRoot("root", null)
    }

    override fun onLoadChildren(parentId: String, result: Result<MutableList<android.media.browse.MediaBrowser.MediaItem>>) {
        result.sendResult(mutableListOf())
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        playerA?.release()
        playerB?.release()
    }
}
