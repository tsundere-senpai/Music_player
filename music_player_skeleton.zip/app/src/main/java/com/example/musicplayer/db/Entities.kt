package com.example.musicplayer.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String?,
    val album: String?,
    val uri: String,
    val durationMs: Long = 0L,
    val folderUri: String? = null,
    val playCount: Int = 0,
    val lastPlayed: Long? = null
)

@Entity(tableName = "favorites")
data class Favorite(@PrimaryKey val trackId: String)

@Entity(tableName = "play_history")
data class PlayHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val playedAt: Long = System.currentTimeMillis()
)
