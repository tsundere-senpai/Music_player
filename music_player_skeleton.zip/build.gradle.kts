// Root build file
plugins {
    kotlin("android") version "1.9.21" apply false
    id("com.android.application") version "8.1.0" apply false
    id("com.android.library") version "8.1.0" apply false
}

// Note: Open this project in Android Studio which will sync and download the Gradle wrapper/SDK.
